import React from 'react'

const Person = ({ person }) => {
  return (
    <li>{person.name}</li>
  )
}
export default Person;
