import React from 'react'

const Nations = ({ nations }) => {
  return (
    <li>{nations.name}</li>
  )
}
