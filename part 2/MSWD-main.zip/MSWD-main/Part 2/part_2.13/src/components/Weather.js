import React from 'react'

const Weather = ({ weather }) => {
  return (
    <li>{weather.name}</li>
  )
} 
